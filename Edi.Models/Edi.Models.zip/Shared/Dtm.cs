﻿namespace Edi.Models.Shared
{
    public class Dtm
    {
        // This class will have ID and dtm specific elements
        /// <summary>
        /// ID - Database ID
        /// </summary>
        public int ID { get; set; }
    }
}
